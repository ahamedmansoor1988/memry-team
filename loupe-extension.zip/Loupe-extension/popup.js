const btn    = document.getElementById("extractBtn");
const status = document.getElementById("status");

btn.addEventListener("click", () => {
  btn.disabled = true;
  status.className = "status";
  status.textContent = "Extracting…";

  chrome.runtime.sendMessage({ type: "EXTRACT_STYLES" }, (res) => {
    btn.disabled = false;
    if (chrome.runtime.lastError || res?.error) {
      status.className = "status error";
      status.textContent = res?.error ?? "Something went wrong.";
    } else {
      status.className = "status success";
      status.textContent = `✓ ${res.count} text elements sent to Loupe.`;
      setTimeout(() => window.close(), 1500);
    }
  });
});
