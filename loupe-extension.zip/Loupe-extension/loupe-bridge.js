// Bridge between the Loupe app (localStorage) and the extension (chrome.storage)

let lastScrapeRequest = null;
let lastStylesTimestamp = 0;

function checkScrapeRequest() {
  try {
    const raw = localStorage.getItem("loupe_scrape_request");
    if (!raw) return;
    const req = JSON.parse(raw);
    if (!req?.url || !req?.timestamp) return;
    if (req.timestamp === lastScrapeRequest) return; // already handled

    lastScrapeRequest = req.timestamp;

    // Tell background to open the URL and extract styles
    localStorage.setItem("loupe_scrape_status", JSON.stringify({ status: "fetching", url: req.url }));
    chrome.runtime.sendMessage({ type: "SCRAPE_URL", url: req.url }, (res) => {
      if (chrome.runtime.lastError) return;
      const status = res?.ok ? "ready" : "error";
      localStorage.setItem("loupe_scrape_status", JSON.stringify({ status, count: res?.count ?? 0 }));
    });
  } catch {}
}

function syncExtractedStyles() {
  chrome.storage.local.get("loupe_extracted_styles", (stored) => {
    const d = stored.loupe_extracted_styles;
    if (d && d.timestamp && d.timestamp !== lastStylesTimestamp) {
      lastStylesTimestamp = d.timestamp;
      // Support both old (styles[]) and new (data{}) format
      const payload = d.data
        ? { data: d.data, url: d.url, timestamp: d.timestamp }
        : { styles: d.styles, url: d.url, timestamp: d.timestamp };
      localStorage.setItem("loupe_bridge_styles", JSON.stringify(payload));
    }
  });
}

// Poll for requests from the app, and sync styles back
setInterval(checkScrapeRequest, 500);
setInterval(syncExtractedStyles, 1000);

// Run once on load
checkScrapeRequest();
syncExtractedStyles();
