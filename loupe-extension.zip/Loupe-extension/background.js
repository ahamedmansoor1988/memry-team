async function extractComputedStyles() {
  await document.fonts.ready;
  await new Promise(r => setTimeout(r, 600));

  // ── Font diagnostic ──────────────────────────────────────────────────────
  const loadedFonts = [...document.fonts].map(f => ({
    family: f.family,
    status: f.status,
  }));
  const headingEl = document.querySelector('h1, h2, h3');
  const computedHeading = headingEl
    ? window.getComputedStyle(headingEl).fontFamily
    : 'no heading found';
  console.log('[Loupe font diagnostic]', JSON.stringify({ loadedFonts, computed: computedHeading }, null, 2));

  // Set of font family names that are actually loaded
  const loadedFamilySet = new Set(
    loadedFonts
      .filter(f => f.status === 'loaded')
      .map(f => f.family.replace(/['"]/g, '').trim().toLowerCase())
  );

  // Read CSS-declared font-family from stylesheet rules (bypasses computed fallback)
  function getDeclaredFontFromCSS(el) {
    for (const sheet of [...document.styleSheets]) {
      try {
        const rules = [...(sheet.cssRules || [])];
        // Walk backwards so last (highest-specificity in source order) wins
        for (let i = rules.length - 1; i >= 0; i--) {
          const rule = rules[i];
          if (!(rule instanceof CSSStyleRule)) continue;
          const ff = rule.style.fontFamily;
          if (!ff || ff.includes('var(')) continue;
          try {
            if (el.matches(rule.selectorText)) {
              const first = ff.split(',')[0].replace(/['"]/g, '').trim();
              if (first) return first;
            }
          } catch {} // invalid selector
        }
      } catch {} // cross-origin stylesheet
    }
    return null;
  }

  function rgbToHex(rgb) {
    if (!rgb || rgb === 'transparent' || rgb === 'rgba(0, 0, 0, 0)') return null;
    const m = rgb.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (!m) return null;
    return '#' + [m[1], m[2], m[3]].map(x => parseInt(x).toString(16).padStart(2, '0').toUpperCase()).join('');
  }

  function resolveFont(cs, el) {
    let family = cs.fontFamily;

    // Resolve CSS custom properties (e.g. font-family: var(--font-heading))
    if (family.includes('var(')) {
      const varName = family.match(/var\(\s*(--[^,)\s]+)/)?.[1];
      if (varName) {
        const resolved = cs.getPropertyValue(varName).trim().replace(/['"]/g, '');
        if (resolved && !resolved.includes('var(')) family = resolved;
      }
    }

    // Walk the cascade to find the first loaded font
    const cascade = family.split(',').map(f => f.replace(/['"]/g, '').trim());
    for (const f of cascade) {
      if (loadedFamilySet.has(f.toLowerCase())) return f;
    }

    // Scenario 1 fix: web font not loaded in background tab →
    // read declared font-family from stylesheet rules instead of computed value
    const cssFont = getDeclaredFontFromCSS(el);
    if (cssFont) return cssFont;

    // Return the first declared font regardless of load status
    return cascade[0] || family;
  }

  function isVisible(el) {
    const cs = window.getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    if (r.right < -200 || r.bottom < -200 || r.left > window.innerWidth + 200) return false;
    return true;
  }

  const selectors = 'h1, h2, h3, h4, h5, h6, p, a, li, button, label, span, td, th';
  const elements = Array.from(document.querySelectorAll(selectors)).filter(isVisible);

  const textMap = new Map();

  for (const el of elements) {
    const text = (el.innerText || el.textContent || '').trim();
    if (!text || text.length < 2 || text.length > 200) continue;

    const cs = window.getComputedStyle(el);
    const fontSize = parseFloat(cs.fontSize) || 0;
    if (fontSize < 8) continue;

    const key = text.slice(0, 60);
    const existing = textMap.get(key);
    if (!existing || fontSize > existing._fontSize) {
      textMap.set(key, {
        text:        text.slice(0, 100),
        fontFamily:  resolveFont(cs, el),
        fontSize:    cs.fontSize,
        fontWeight:  cs.fontWeight,
        color:       rgbToHex(cs.color),
        _fontSize:   fontSize,
      });
    }
  }

  const styles = Array.from(textMap.values())
    .map(({ _fontSize, ...rest }) => rest)
    .slice(0, 150);

  return { styles, fontDiagnostic: { loadedFonts, computed: computedHeading } };
}

async function scrapeUrl(url) {
  return new Promise((resolve) => {
    chrome.tabs.create({ url, active: false }, (tab) => {
      const tabId = tab.id;

      function onUpdated(updatedTabId, changeInfo) {
        if (updatedTabId !== tabId || changeInfo.status !== 'complete') return;
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.scripting.executeScript(
          { target: { tabId }, func: extractComputedStyles },
          (results) => {
            const data = results?.[0]?.result ?? { styles: [] };
            chrome.tabs.remove(tabId);
            resolve({ data, url });
          }
        );
      }

      chrome.tabs.onUpdated.addListener(onUpdated);
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.tabs.remove(tabId, () => {});
        resolve({ data: { styles: [] }, url });
      }, 20000);
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SCRAPE_URL" && msg.url) {
    scrapeUrl(msg.url).then(async ({ data, url }) => {
      await chrome.storage.local.set({
        loupe_extracted_styles: {
          styles:        data.styles,
          fontDiagnostic: data.fontDiagnostic,
          url,
          timestamp:     Date.now(),
        },
      });
      sendResponse({ ok: true, count: data.styles?.length ?? 0 });
    });
    return true;
  }
});
