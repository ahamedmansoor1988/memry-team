async function extractComputedStyles() {
  await document.fonts.ready;
  // Small settle delay — background tabs can finish "complete" before web fonts paint
  await new Promise(r => setTimeout(r, 600));

  function rgbToHex(rgb) {
    if (!rgb || rgb === 'transparent' || rgb === 'rgba(0, 0, 0, 0)') return null;
    const m = rgb.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (!m) return null;
    return '#' + [m[1], m[2], m[3]].map(x => parseInt(x).toString(16).padStart(2, '0').toUpperCase()).join('');
  }

  function resolveFont(cs) {
    let family = cs.fontFamily;
    // Try to resolve CSS custom properties (Elementor, CSS frameworks etc.)
    if (family.includes('var(')) {
      const varName = family.match(/var\(\s*(--[^,)\s]+)/)?.[1];
      if (varName) {
        const resolved = cs.getPropertyValue(varName).trim().replace(/['"]/g, '');
        if (resolved && !resolved.includes('var(')) family = resolved;
      }
    }
    return family.split(',')[0].replace(/['"]/g, '').trim();
  }

  function isVisible(el) {
    const cs = window.getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    // Skip elements positioned far off screen (hidden clones, SEO duplicates)
    if (r.right < -200 || r.bottom < -200 || r.left > window.innerWidth + 200) return false;
    return true;
  }

  // Query elements directly — no text node walking, no parent climbing
  const selectors = 'h1, h2, h3, h4, h5, h6, p, a, li, button, label, span, td, th';
  const elements = Array.from(document.querySelectorAll(selectors)).filter(isVisible);

  // For duplicate text, keep the element with the largest font size
  const textMap = new Map();

  for (const el of elements) {
    const text = (el.innerText || el.textContent || '').trim();
    if (!text || text.length < 2 || text.length > 200) continue;

    const cs = window.getComputedStyle(el);
    const fontSize = parseFloat(cs.fontSize) || 0;
    if (fontSize < 8) continue;

    const key = text.slice(0, 60);
    const existing = textMap.get(key);
    if (!existing || fontSize > existing._fontSize) {
      textMap.set(key, {
        text: text.slice(0, 100),
        fontFamily:  resolveFont(cs),
        fontSize:    cs.fontSize,
        fontWeight:  cs.fontWeight,
        color:       rgbToHex(cs.color),
        _fontSize:   fontSize,
      });
    }
  }

  const styles = Array.from(textMap.values())
    .map(({ _fontSize, ...rest }) => rest)
    .slice(0, 150);

  return { styles };
}

async function scrapeUrl(url) {
  return new Promise((resolve) => {
    chrome.tabs.create({ url, active: false }, (tab) => {
      const tabId = tab.id;

      function onUpdated(updatedTabId, changeInfo) {
        if (updatedTabId !== tabId || changeInfo.status !== 'complete') return;
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.scripting.executeScript(
          { target: { tabId }, func: extractComputedStyles },
          (results) => {
            const data = results?.[0]?.result ?? { styles: [] };
            chrome.tabs.remove(tabId);
            resolve({ data, url });
          }
        );
      }

      chrome.tabs.onUpdated.addListener(onUpdated);
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.tabs.remove(tabId, () => {});
        resolve({ data: { styles: [] }, url });
      }, 20000);
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SCRAPE_URL" && msg.url) {
    scrapeUrl(msg.url).then(async ({ data, url }) => {
      await chrome.storage.local.set({
        loupe_extracted_styles: { styles: data.styles, url, timestamp: Date.now() }
      });
      sendResponse({ ok: true, count: data.styles?.length ?? 0 });
    });
    return true;
  }
});
