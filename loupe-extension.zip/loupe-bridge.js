// Injected into the Loupe app page — bridges extension → page
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "LOUPE_STYLES_READY") {
    window.dispatchEvent(new CustomEvent("loupe:styles", { detail: msg }));
  }
});

// Also check storage on load (in case extraction happened before Loupe was open)
chrome.storage.local.get("loupe_extracted_styles", (data) => {
  if (data.loupe_extracted_styles) {
    window.dispatchEvent(new CustomEvent("loupe:styles", { detail: data.loupe_extracted_styles }));
  }
});
