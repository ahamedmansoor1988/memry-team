// Extraction script injected into the live site tab
const EXTRACT_SCRIPT = `
(function() {
  function rgbToHex(rgb) {
    if (!rgb || rgb === 'transparent' || rgb === 'rgba(0, 0, 0, 0)') return null;
    const m = rgb.match(/rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)/);
    if (!m) return null;
    return '#' + [m[1],m[2],m[3]].map(x => parseInt(x).toString(16).padStart(2,'0').toUpperCase()).join('');
  }

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const seen = new Set();
  const results = [];
  let node;

  while (node = walker.nextNode()) {
    const text = node.textContent.trim();
    if (!text || text.length < 2 || seen.has(text)) continue;
    seen.add(text);
    const el = node.parentElement;
    if (!el || el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
    const cs = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    results.push({
      text: text.slice(0, 100),
      fontFamily: cs.fontFamily.split(',')[0].replace(/['"]/g, '').trim(),
      fontSize: cs.fontSize,
      fontWeight: cs.fontWeight,
      lineHeight: cs.lineHeight,
      color: rgbToHex(cs.color),
      letterSpacing: cs.letterSpacing
    });
    if (results.length >= 200) break;
  }
  return results;
})();
`;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "EXTRACT_STYLES") {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) { sendResponse({ error: "No active tab" }); return; }

      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: new Function(`return ${EXTRACT_SCRIPT}`)(),
        });

        const styles = results[0]?.result ?? [];

        // Store in chrome.storage so Loupe page can read it
        await chrome.storage.local.set({
          loupe_extracted_styles: {
            styles,
            url: tab.url,
            title: tab.title,
            timestamp: Date.now(),
          }
        });

        // Also try to notify any open Loupe tabs directly
        chrome.tabs.query({}, (allTabs) => {
          for (const t of allTabs) {
            if (t.url?.includes("memry-team-opal.vercel.app") || t.url?.includes("localhost:3000")) {
              chrome.tabs.sendMessage(t.id, {
                type: "LOUPE_STYLES_READY",
                styles,
                url: tab.url,
                title: tab.title,
              }).catch(() => {});
            }
          }
        });

        sendResponse({ ok: true, count: styles.length });
      } catch (err) {
        sendResponse({ error: String(err) });
      }
    });
    return true; // keep channel open for async response
  }
});
